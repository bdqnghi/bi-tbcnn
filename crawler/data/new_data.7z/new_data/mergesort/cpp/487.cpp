/**
 *归并排序
 *快速排序
 */

#include <iostream>
#include <cstdlib>
#include <alogrithm>

using namespace std;

template<typename T> void MergeSort(const T *a,size_t sz)
{
}

